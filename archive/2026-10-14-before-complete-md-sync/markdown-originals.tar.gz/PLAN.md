# PLAN: "Stop Overthinking, Keep Passing the Tests"

## Completed LoRA combinations — 14 October 2026

All six planned combinations now have results for the same **464 problems**, one attempt each.

- **0.8B:** LoRA + OFF **14.0% (65/464)**; LoRA + limit 512 **14.4% (67/464)**.
- **2B:** LoRA + OFF **35.6% (165/464)**; LoRA + limit 1,024 **41.2% (191/464)**.
- **4B:** LoRA + OFF **64.7% (300/464)**; LoRA + limit 2,048 **71.6% (332/464)**.

LoRA + OFF does not consistently improve on OFF without LoRA.
The 2B and 4B limit combinations have not established a reliable accuracy gain over the free limit.
Compare first attempts with first attempts; keep all-attempt problem averages labelled separately.
No further run is needed to complete these six configurations.
The document rebuild uses saved results and spends no Colab units.

Read [the full easy thesis](easy-thesis/FULL-THESIS.md), including benchmark, difficulty, token and uncertainty tables.
The formal thesis retains its historical results.
[Checked result archive and calculations](results/lora-controls/README.md).

## Full 464 update — 14 October 2026

**2B LoRA-1 alone: 34.4%;4B LoRA-1 alone: 56.8%. Both now cover 464/464.**
The exact missing40 runs passed 1/40 (2B) and 12/40 (4B), with one attempt each.
No existing 424 LoRA-alone IDs were repeated.
The scores above average attempts within problems, then weight problems equally.

For 2B on the same 464 first attempts:
**LoRA + limit1024: 41.2% (191/464); LoRA alone: 34.9% (162/464); OFF: 32.5% (151/464).**
The combination's gain over LoRA alone is 6.2 points, interval +2.4 to +10.1.
Its gain over OFF is 8.6 points, interval +4.5 to +12.9.
LoRA alone's smaller lead over OFF remains inconclusive.
Limit alone is 38.6%; the combination's gain over it remains inconclusive.

Missing40 work is complete. Do not rerun Notebook 22 or the existing 424 answers.
Other incomplete methods remain outside scope.
[Updated results and both weighting rules](results/lora-missing40/README.md).


## Existing LoRA + limit extension — Decision 102, 14 October 2026

Notebook 21 tests Qwen3.5-2B with the existing LoRA-1 and a 1,024 thinking-token cap.
Generate one attempt for each of the 464 frozen problems. No training or other model is run.
Keep seed 3407, original prompts and sampling, overall caps 4,096/8,192, and no repeat stopping.
The first 16 are technical checks and count toward the total; do not gate on their accuracy.
Compare saved first attempts for limit1024, OFF, ON (464), and LoRA-1 without a limit (424).
Use shared IDs only and report actual generated/graded coverage and paired uncertainty.
The main comparison is against the same limit without LoRA, not unlimited thinking.
Keep results separate until this new run is checked; do not overwrite the combined thesis scores.
Budget: user-approved 45-unit total estimated ceiling for the revised workflow across setup, generation, grading, and reports.
Retain recorded usage; finish immediately when the 464-problem run and its reports are done.
Earlier failed attempt costs are separate. Enter the current rate and balance; preserve the old ledger and use v2 for resumes.
Readable notebook cells clone/update GitHub, following notebooks 18–20.
Frozen questions/IDs and reference grades live in `results/lora-limit-inputs/`; there is no encoded bundle.
Like earlier notebooks, tests load from fixed external data sources; their contents are checked and cached on Drive.
The original lora100 weight file is required on Drive before package installation.
The first real GPU attempt failed during PEFT adapter injection, before any answers.
The corrected notebook removes unused TorchAO and checks adapter injection on a tiny CPU model first.
Zero-answer failures skip grading and show FAILED, not a model accuracy score.
The failed run reported 11.31/15 estimated units. The user then approved a 45-unit total ceiling
to finish all 464 problems, retaining recorded usage and all old logs.
The corrected GPU run is complete: 41.2% (191/464), one attempt each. Details: [Notebook 21 Q&A](qa/45-lora-with-limit-notebook.md).

## Retrospective reporting update — Decision 101, 13 October 2026

The easy thesis now reports **464 unique test problems** as one combined analysis.
This reporting choice was made after the runs; it does not change the original hypotheses below.
Use all saved attempts, average success within each problem, then average problems equally.
Show coverage for every method. Compare methods only on shared IDs.
2B and 4B LoRA-1 each use 424 shared problems; LoRA-2 remains a 234-problem analysis.
Report problem-level paired bootstrap intervals (2,000 resamples, seed 3407), unadjusted for selection.
The original protocol and formal thesis remain historical; no new training or evaluation is authorized here.
Sources and rebuild commands: [combined analysis](results/combined/README.md).

---

> **What is this file?** The research design: what exactly we will do.
> New here? Read [ROADMAP.md](ROADMAP.md) first.
> Every choice has its reason in [DECISIONS.md](DECISIONS.md).
> Teacher questions and answers are in [qa/](qa/).
> Hard word? See [GLOSSARY.md](GLOSSARY.md).
> The proposal that matches this plan is in [proposal/](proposal/).
>
> Status: **planned, nothing run yet** (2026-09-13).
> Cut to **one research question** on 2026-09-13 (DECISIONS #25).

---

## 1. The whole thesis on one screen

```text
PROBLEM     Small AI models "think" a lot on code, even easy code.
            That wastes time and computer power.
GAP         Nobody has tested this on ONE small model with a thinking ON/OFF switch:
            is TRAINING it to think shorter better than the free options?
            (free options = switch thinking OFF, set a thinking limit, or say "think briefly")
QUESTION    Does training on the model's shortest correct answers give
            a better balance of accuracy and length than the free options?
EXPERIMENT  Same model, same test problems, 5 ways of answering
RESULTS     Accuracy vs. thinking length (in tokens), with error bars
CONCLUSION  Is training worth it for code, on a small model?
```

A *token* is a small piece of text, about ¾ of a word.

**Everyday example.** A student writes 5 pages for every exam question, even
"2 + 2". We want to teach them to write short answers when short is enough,
without getting more questions wrong. We also check whether simply telling them
"don't think, just answer" works as well.

---

## 2. Why only one question

We want **one** study done well, with the best chance of a positive result, so it can
become a conference paper.

- **Savings are likely.** The same method (keep the shortest correct answer, train on it)
  already cut tokens on math (Munkhbat et al. 2025) and on code with a 7B model (SEER).
- **Clearest gap.** Our search found this gap (G-A, below) most clearly open.
- **Fits free GPUs.** It needs only **one** training run, so the free GPU time goes into doing it properly.
- **No need to beat thinking ON on accuracy.** We need a **better balance**:
  much shorter, almost as accurate, and more accurate than the free options.

**Honest:** nobody can promise a positive result. The room-to-shorten check in week 3 (§7)
warns us early.

---

## 3. Scope: easy + medium code problems only

We leave out hard problems, and we write this down as a limitation. Four reasons:

| # | Reason | In simple words |
|---|---|---|
| 1 | **Memory** | Thinking on hard problems is often 10,000–15,000 tokens. Training on a free T4 GPU fits about 3,500. |
| 2 | **Nothing to learn from** | A 4B model solves few hard problems, so there are few correct answers to train on. |
| 3 | **Time** | Long answers × 4 tries × thousands of problems is too slow on free GPUs. |
| 4 | **Nothing to measure** | If the base model scores about 0% on hard problems, we can't ask "did accuracy drop?" |

**Fair testing:** the 3,500-token limit is **only for training examples**.
At test time, every way of answering gets the **same** thinking limit (for example 8,000 tokens).
We record how often each one hits that limit.

**Risk: "always stop early".** A model that only sees short answers may learn to stop too early
on medium problems. Two protections:
1. LoRA adds a small add-on, so the base model stays unchanged.
2. Our selection rule skips answers shorter than half the median correct length.

---

## 4. The gap (from the 2026-09-13 paper search)

Full reading list: [PAPERS.md](PAPERS.md). Full search notes: [research/gaps.md](research/gaps.md).

| # | Gap | Verdict | What we do |
|---|---|---|---|
| **G-A** | On one small model with a thinking switch, nobody compares for code: thinking OFF · thinking budget · "think briefly" prompt · thinking ON · thinking ON + LoRA trained on shortest correct answers | OPEN | **The whole thesis** |

**Future work (dropped on 2026-09-13, DECISIONS #25):**
- how much training data is needed (a learning curve)
- does training on code also shorten math thinking (code → math transfer)
- LoRA size 8 vs 32
- fresh problems vs. problems the model may have seen
- GRPO (training with rewards)
- hard problems

**We do NOT claim to be:**
- the first to shorten code reasoning (SEER and ASAP did),
- the first on cheap GPUs (TokenSkip did),
- the first to show math → code transfer (HAPO and LC-R1 did).

---

## 5. The 9 research questions

| Question | Answer |
|---|---|
| **What am I testing?** | Does LoRA training on shortest correct answers give a better balance of accuracy and length on code than the built-in switch and simple prompts? |
| **Hypothesis** | Compared with thinking ON, the trained model: **(1)** uses ≥25% fewer thinking tokens, **(2)** loses ≤3 points of first-try pass rate (on the same problems), **(3)** is more accurate than thinking OFF, the thinking budget and the "think briefly" prompt. |
| **What I change** (independent variable) | The way of answering: thinking OFF · thinking budget (stop at k tokens) · "think briefly" prompt · thinking ON · thinking ON + our LoRA |
| **What I measure** (dependent variables) | First-try pass rate, called *pass@1* (averaged over 4 tries) · thinking tokens · % of answers that hit the thinking limit |
| **What we compare against** (baselines) | Thinking ON (the normal way), thinking OFF, thinking budget, "think briefly" prompt |
| **Data** | §6 |
| **How we judge** (metric) | Error bars (95%) made by comparing the same problems before and after, re-sampled many times (*paired bootstrap, grouped by problem*) · fixed seeds · a chart of accuracy vs. tokens |
| **Supports it** | All 3 parts are true on the code test set |
| **Proves it wrong** | A free option is as accurate as the trained model, or accuracy drops by more than 3 points |

---

## 6. Data

⚠️ Dataset ids come from the 2026-09-13 search. Re-check each one in the first data notebook.

| Role | Dataset (Hugging Face id) | Size | Notes |
|---|---|---|---|
| **Train (code)** | **Since 2026-09-22: 200 MBPP+ problems (`evalplus/mbppplus`) + 80 older LiveCodeBench problems (release v1, 40 easy + 40 medium, all before 2025-02)** (DECISIONS #65, #66). ~~`agentica-org/DeepCoder-Preview-Dataset` · `codeparrot/apps` introductory~~ | 280 | Loaded and graded by code already proven in the mini-thesis. The LiveCodeBench part adds medium, read-input-print-output problems like our test set. `scripts/overlap_check.py` removes any training problem close to a test problem. |
| **Test (code)** | HumanEval+ (164) + `livecodebench/code_generation_lite` easy + medium, fresh (70) | **234** (fixed 2026-09-20, DECISIONS #58) | Never used for training. The base model and the trained model see the same problems, so the comparison stays fair. ~~MBPP+ (378)~~ and the rest were cut to fit free Colab in one week: 1,000 problems × 5 ways × 4 tries ≈ 13+ GPU hours, 234 problems ≈ 3–4 hours. **Chosen before any result was seen.** Cost, to state in the thesis: fewer problems means wider error bars. |

**How we load LiveCodeBench** (checked 2026-09-17): it uses a Python loading script that Hugging Face
refuses to run, so we download its `.jsonl` files directly. Each problem has a date (`contest_date`)
and a difficulty.

**How many problems are fresh** (counted 2026-09-17): from February 2025 on there are 131 problems:
**31 easy + 39 medium** + 61 hard. So only **70 fresh easy/medium problems**. That is too few to carry the
main result, so the fresh set is a side note; the main comparison uses the full paired test set (DECISIONS #41).

**Overlap check** (before any training): remove every training problem that matches
a test problem, exactly or nearly.

**How big must the test set be?**
- A 2–3 point accuracy change is small, so it is hard to see.
- Comparing the **same** problems before and after (a *paired* comparison) needs
  about **1,000–2,000 problems** to see it clearly.
- A big token change (−25%) shows with only a few hundred problems.

Details: [research/data-size-and-test-size.md](research/data-size-and-test-size.md).

---

## 7. Model, memory, and the checks

### The model

- **Main: `unsloth/Qwen3.5-2B`.** Released February 2026. Thinking ON/OFF switch. Apache-2.0 licence.
  4.58 GB in 16-bit, so the **whole model fits on a free Colab T4** (~15 GB) with plenty of room
  for the answers. ✅ Checked 2026-09-20 by downloading its own `chat_template.jinja`:
  `enable_thinking` is on line 149, thinking is OFF by default, and the markers are
  `<think>` … `</think>`.
  ❌ **No published training cutoff date.** We give up the proof that the test problems are new
  to the model (DECISIONS #54). The thesis must say so plainly.
- **Backup: `unsloth/Qwen3.5-4B`** (3.06 GB squeezed), used only if the 2B fails the ≥40% gate.
- ~~**Was: `google/gemma-4-E4B-it`**, with Qwen3.5-4B as backup.~~ Changed 2026-09-20, DECISIONS
  #52, #53: Gemma-4-E4B did not fit a free T4 (its 5.25 GB per-layer word table had to sit in CPU
  memory, which is why it wrote at 4.4 tokens/s), and the Mac that ran Gemma-4-E2B needed
  **250 seconds for one medium problem**.

### How a 16 GB model fits in a 15 GB GPU

```text
A model = a huge list of numbers. Gemma-4-E4B has 8.0 billion of them.

16-bit  (2 bytes each)                → 16.0 GB   ✗ bigger than the GPU     (checked on HF)
4-bit   (only part of it squeezed)    → 11.0 GB   ✓ the file we load        (checked on HF)
On the GPU while training (short examples) → 10.7 GB peak  (measured by Unsloth on a T4)
```

Only 3.5 of the 8 billion numbers get squeezed to 4-bit. The word lookup tables and
the image and audio parts stay 16-bit. That's why the file is 11 GB, not 4 GB.
*Everyday example:* a big photo saved as a JPEG. A bit less detail, much smaller.

**First real try (2026-09-19): loading crashed on a free Colab T4.** The biggest 16-bit part is
the *per-layer word table* (5.25 GiB). The T4 has no bf16, so Unsloth converts it to float16
on the GPU, which needs a second copy for a moment: 10.22 + 5.25 > 14.56 GiB.
**Fix:** keep that table in CPU memory, and run on Kaggle (more CPU memory). Backup: split over
Kaggle's 2 GPUs. From now on the memory check reports **GPU and CPU memory, and the load mode**.
Details: [results/2026-09-19-notebook11-out-of-memory.md](results/2026-09-19-notebook11-out-of-memory.md), DECISIONS #43.

### The two checks (week 3, before spending GPU days)

1. **Memory check.** Train on 50 examples, each up to 3,500 tokens long.
   - Peak memory ≤14 GB → keep Gemma.
   - Otherwise → switch to Qwen3.5-4B (9.6 GB measured on a T4).
2. **Room-to-shorten check.** The base model answers 200 training problems, 4 times each.
   - **Share of problems solved at least once** must be **≥40%**.
   - **Room to shorten** (shortest correct length ÷ average correct length) must be **≤0.75**.
     This means short answers are at least 25% shorter. **This is the number that answers
     "will fine-tuning really cut tokens?"** If every correct answer is the same length, there is
     nothing to cut and the training cannot help.
   - Both are printed by `scripts/check_gates.py`. A short version runs first in notebook 12, so
     we find out in one afternoon instead of after a week of GPU time. Since 2026-09-21
     (DECISIONS #59) that short version is a **free go/no-go test**: 30 easy (HumanEval) + 20
     **medium** (LiveCodeBench) problems, gates checked **separately** for easy and medium, plus a
     float16-vs-float32 check and a speed check. **No money is spent until it passes.**
   - Fails → **ask each problem 8 times instead of 4** (more chances for a short correct answer), then check again.
3. **Selection rule.** Keep the shortest correct answer, but not shorter than half the median correct length
   (the S3-CoT paper warns that the very shortest answers hurt accuracy).

### Risks we have not checked yet (checked in weeks 1–3)

- A Gemma-4 bug on the T4: a number gets too big in the audio part in 16-bit mode. We use text only.
- Speed on the T4: Unsloth runs Gemma 4 in a float32/float16 mix there (no bf16), and our per-layer table sits in CPU memory. Both may slow it down. Measured in notebook 11.
- ~~Whether vLLM runs Gemma-4 on a T4.~~ **Closed 2026-09-20 (DECISIONS #57): we do not use vLLM.** It has known bugs loading LoRA adapters on a T4, and our fifth way of answering *is* a LoRA. We use plain `transformers` to answer and Unsloth to train. Notebook 12 still runs a small vLLM **speed try** on the base model (no LoRA), only to know whether paying for a faster GPU would help (DECISIONS #59).
- float16 on the T4 may make Qwen write garbage (no bf16 on a T4). Checked for free in notebook 12, step 6b, against float32 (DECISIONS #59).
- Free GPU limits change. Colab: up to 12 h per session, no published weekly limit. Kaggle: ~30 GPU-hours per week on 2×T4.

---

## 8. The method, step by step

```text
1. The base model answers each training problem 4 times (thinking ON)
          │
2. Grade every answer with the problem's tests (in a sandbox, a safe closed box)
          │
3. For each problem: keep the SHORTEST CORRECT answer (not below ½ the median)
          │
4. Train ONE LoRA add-on on those (problem → short correct answer)
          │
5. Test all 5 ways of answering on the same test problems, same limits, same seeds
```

**First, small and free (DECISIONS #60):** the same 5 steps run once as a **mini-thesis** in
notebook 13, on MBPP+ (100 train / 100 other test problems, not our final test set), with LoRAs
on 25%, 50% and 100% of the examples. It tells us early whether training cuts thinking at all,
and whether more training data would help (the learning curve).

---

## 9. Timeline (12 weeks, same as the proposal)

| Weeks | Work |
|---|---|
| 1–2 | Learn the tools, set up Colab/Kaggle, check the model and datasets, build the sandbox grader, first call with thinking ON vs. OFF |
| 3 | Memory check + room-to-shorten check |
| 4–5 | Test the 4 free ways of answering |
| 6–7 | Build training data (answer, grade, select), overlap check |
| 8–9 | Train the LoRA add-on, test it |
| 10–12 | Error bars, chart, write the thesis + paper draft |

---

## 10. The compute budget: 69 Colab units (DECISIONS #65, 2026-09-22)

**The hard limit:** 69 compute units must finish the whole thesis. The A100 costs **5.3 units per
hour** (shown by Colab), so 69 units = **13.0 A100-hours**. 1 unit = about 11 minutes of A100.

**The measured cost unit** (notebook 13, A100, batch 64, 4,096-token limit): one batch of thinking
answers takes about **230 seconds = 0.34 units**. A batch waits for its slowest answer, and the
4,096 limit caps that, so this is also the cost for medium problems (estimate).

| Stage | What (notebook 14, all on the A100) | Units |
|---|---|---|
| smoke | Every way on 2 problems per dataset, tiny limit: does every code path work? | 0.7 |
| **A** | **Must.** 234 test problems × OFF, ON, brief, limit, LoRA-1 × 1 try | 10.3 |
| B1 | Training answers: 200 MBPP+ + 80 older LiveCodeBench × 4 tries | 7.2 |
| B2 | Train LoRA-2 (3 epochs) | 1.0 |
| B3 | Test LoRA-2, 1 try | 2.5 |
| C | A second try for every way | 12.8 |
| D | The cut-off thinking-ON answers again at 16,384 tokens | 2.7 |
| | **Planned total** (+ ~2–3 for setup and model loading) | **~37–40** |
| | **Floor** that is never spent (fixes, re-runs) | **20** |

Token limits (DECISIONS #66): **4,096** for HumanEval+, **8,192** for LiveCodeBench, the same for every way.
The "limit" way cuts thinking at **1,024** tokens.

**Rules that protect the budget:**
1. **Debug on the T4 or CPU, produce on the A100.** New code runs on 2–3 problems first.
2. **Disconnect the A100 when nothing runs** (Runtime → Disconnect and delete runtime). Idle still costs.
3. **Grade on a CPU runtime.** Grading doesn't need a GPU; the answers are on Drive.
4. **Before each stage, write down the units left.** Start a stage only if *units left − its cost ≥ 20*.
   If not, skip stages from the end: 4 first, then 3, then 2. Stage 1 always runs.
5. **Try batch 128 once** in stage 1. If a batch takes less than 1.6× as long as batch 64, keep 128
   (it saves 30–40%). Measured, not assumed.
6. **Everything resumes:** a crash costs at most the batch in progress.

⚠️ Estimates built on one measured number (230 s per batch). Setup time, model loading and the
T4 and CPU unit prices are **not measured yet**. The stage 1 numbers will be checked against the
units actually used, and this table redone.

~~The old free-GPU table (40M + 30M tokens, tens of T4 hours) is replaced: the free T4 measured
26–30 tokens/s (DECISIONS #62–63).~~

---

## 11. Working inside a 12-hour session limit

A free session is short (Colab "at most 12 h", Kaggle ~12 h, and both can end early),
but we need tens of hours. **We never run one long job.** Every job can **stop and continue later**.

*Everyday example:* reading a long book with a bookmark.

```text
start → connect Google Drive → read the "done" list → skip finished items
      → work → add results every ~20 problems → session dies → start again
```

| Stage | Needs one unbroken run? | How it survives a stop |
|---|---|---|
| Making training data (15–40 h) | No, problems are independent | "done" list + a results file we only add to, on Drive |
| Testing the 5 ways of answering (10–30 h) | No | same |
| LoRA training (3–7 h) | Fits one session | save point every ~30 min (the add-on, the training settings and progress, the data order, and the random seed state) |

**Rules:**
- **Only add** to results files. Never change old lines.
- Every result has a fixed name: `problem_id + sample_index + policy` (policy = the way of answering).
  This tells us what is already done.
- After each write, make sure the result is **really saved to disk** (flush + `fsync`).
- Each item has its own fixed seed, so the same item gives the same output in any session.
- Store the model's raw answers exactly as written, so re-grading never needs the GPU.

**Which GPU for what:**
- **Kaggle is the main worker.** Its "Save & Run All" keeps running **with the browser closed**,
  and it has 2 T4s (≈ 2 workers).
- **Colab** needs the browser tab open, so it is the second worker and the place to fix bugs.

⚠️ **Not checked yet (check in week 1):** whether a 2×T4 Kaggle session uses 1 or 2 hours
of the ~30 GPU-hour weekly limit per hour of real time.

**Cut the work before asking for more sessions.** Write many answers at the same time
(vLLM, 32–64 prompts at once). This is **2–5×** faster and changes nothing in the science, so do it first.
Full detail: [research/gpu-time-budget.md](research/gpu-time-budget.md) §8.

---

## 12. Size extension (done 2026-09-29)

**Why:** answer “why only 2B?” and “why only limit 1,024?” (DECISIONS #72–#77).

| Size | Status | Best free way | LoRA-1 |
|---|---|---|---|
| 0.8B (lean, 1 try) | ✅ | OFF 20.5% | 17.9% |
| 2B (main thesis) | ✅ | limit 1024 → 49.8% | 45.5% |
| 4B (2 tries) | ✅ | limit 2048 → 78.2% | 69.9% |

Same 234 problems. Numbers and paper map: [results/RESULTS-INDEX.md](results/RESULTS-INDEX.md).  
Written into the thesis: §5.13 · §6.7 · §7.5.4.

