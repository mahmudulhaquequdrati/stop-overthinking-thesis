# Size comparison: 0.8B · 2B · 4B

## Latest completed LoRA combinations

0.8B: LoRA + OFF **14.0%**, LoRA + limit 512 **14.4%**.
2B: LoRA + OFF **35.6%**, LoRA + limit 1,024 **41.2%**.
4B: LoRA + OFF **64.7%**, LoRA + limit 2,048 **71.6%**.
Each covers 464/464, one attempt each.
Read [the updated full easy thesis](../easy-thesis/FULL-THESIS.md) and
[checked results](lora-controls/README.md). Older tables below retain their original scope.

## Full 464 update — 14 October 2026

**2B LoRA-1 alone: 34.4%;4B LoRA-1 alone: 56.8%. Both now cover 464/464.**
The exact missing40 runs passed 1/40 (2B) and 12/40 (4B), with one attempt each.
No existing 424 LoRA-alone IDs were repeated.
The scores above average attempts within problems, then weight problems equally.

For 2B on the same 464 first attempts:
**LoRA + limit1024: 41.2% (191/464); LoRA alone: 34.9% (162/464); OFF: 32.5% (151/464).**
The combination's gain over LoRA alone is 6.2 points, interval +2.4 to +10.1.
Its gain over OFF is 8.6 points, interval +4.5 to +12.9.
LoRA alone's smaller lead over OFF remains inconclusive.
Limit alone is 38.6%; the combination's gain over it remains inconclusive.

Missing40 work is complete. Do not rerun Notebook 22 or the existing 424 answers.
Other incomplete methods remain outside scope.
[Updated results and both weighting rules](../results/lora-missing40/README.md).


## Current combined view — 464 unique problems

Use [combined/README.md](combined/README.md) for the updated easy-thesis numbers.
Full-coverage headlines: **0.8B OFF 14.7% · 2B limit 1,024 38.6% · 4B limit 2,048 71.9%**.
Every problem has equal weight. Missing methods show coverage, and comparisons use shared IDs.
The [easy thesis](../easy-thesis/PAPER.md) now leads with these combined scores.
The tables below are **historical run-specific results**, not the combined ranking.
Original raw scores remain unchanged.

---

> One page for the teacher and for the paper extension.  
> Numbers checked from graded files in `results/0.8b/`, `results/4b/`, the 2B thesis run,
> `results/2b-limit512/`, and `results/2b-limit2048/`.

## 1. The idea in one picture

```text
Same 234 code problems
        │
   ┌────┴────┐
   ▼         ▼         ▼
 0.8B       2B        4B
   │         │         │
 OFF wins  limit1024  limit2048
 20.5%     49.8%      78.2%
```

**Everyday example.** A weak student (0.8B) does best when told “don’t overthink — just answer.”  
A stronger student (2B/4B) does best with a short thinking budget, not with open-ended thinking.

## 2. Accuracy side by side

| Way | 0.8B (1 try) | 2B | 4B (2 tries) |
|---|---|---|---|
| Thinking OFF | **20.5%** | 40.8% (2 tries) | 69.7% |
| Thinking ON | 7.3% | 42.1% (2 tries) | 64.3% |
| Limit 512 | 17.5% | **45.1%** (2 tries) | 75.4% |
| Limit 1,024 | 13.2% | **49.8%** (2 tries) | 76.5% |
| Limit 2,048 | — | **46.6%** (1 try)* | **78.2%** |
| Limit 4,096 | — | — | 76.7% |
| LoRA-1 | 17.9% | 45.5% (2 tries) | 69.9% |

\* 2B limit2048 = lean fill-in (**1 try**). Caption that in the paper.

**2B limit curve:** 512 → 45.1% · 1024 → **49.8%** · 2048 → 46.6%. **Peaks at 1024.**

**Best free way per size**

| Size | Best free way | Score | Beats LoRA-1? |
|---|---|---|---|
| 0.8B | **OFF** | 20.5% | yes (LoRA-1 17.9%) |
| 2B | **limit 1024** | 49.8% | yes (LoRA-1 45.5%) |
| 4B | **limit 2048** | 78.2% | yes (LoRA-1 69.9%) |

**Limit 512 across sizes:** 0.8B 17.5% · 2B 45.1% · 4B 75.4%.

## 3. What this means

1. **Bigger → more accurate** on every way. Size matters a lot.  
2. **Open thinking (ON) is risky** when the model loops.  
3. **A free limit wins on 2B and 4B.** On 0.8B, **OFF** wins.  
4. **LoRA-1 never beats the best free way** on any of the three sizes.  
5. **Best limit grows with size:** 1024 on 2B → 2048 on 4B. On 2B, **2048 did not beat 1024** (46.6% vs 49.8%).  
6. Fill-ins done: 2B limit512 (#82) and lean limit2048 (#84). No need for 4096 on 2B.

## 4. Honest limits of the comparison

| Checked | Assumed / caveat |
|---|---|
| Same 234 problems, same family (Qwen3.5) | 0.8B and 2B-limit2048 = **1 try**; other 2B/4B = **2 tries** |
| Graded with real benchmark tests | 0.8B skipped limits 2048/4096 on purpose |
| 2B limit512 / limit2048 = fill-in runs | Not the same training mix as 2B’s LoRA-2 |

## 5. One recommendation for users

For small code models on one GPU: **try OFF and a short thinking limit first**.  
On ~2B, about **1,024** thinking tokens was best (512 helps; 2048 did not beat it here).  
On ~4B, about **2,048** was best.  
Train with LoRA only if free ways are not enough.

Join table: [ALL-RESULTS.md](ALL-RESULTS.md) · [RESULTS-INDEX.md](RESULTS-INDEX.md) · DECISIONS #72–#84.

Later lists stay out of the table above. Extra 40: [extra/SUMMARY.md](extra/SUMMARY.md). The 190: [more/SUMMARY.md](more/SUMMARY.md).
