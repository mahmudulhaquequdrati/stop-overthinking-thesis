# Results index — everything for the paper (0.8B · 2B · 4B)

## Completed LoRA combinations — 14 October 2026

All six planned combinations now have results for the same **464 problems**, one attempt each.

- **0.8B:** LoRA + OFF **14.0% (65/464)**; LoRA + limit 512 **14.4% (67/464)**.
- **2B:** LoRA + OFF **35.6% (165/464)**; LoRA + limit 1,024 **41.2% (191/464)**.
- **4B:** LoRA + OFF **64.7% (300/464)**; LoRA + limit 2,048 **71.6% (332/464)**.

LoRA + OFF does not consistently improve on OFF without LoRA.
The 2B and 4B limit combinations have not established a reliable accuracy gain over the free limit.
Compare first attempts with first attempts; keep all-attempt problem averages labelled separately.
No further run is needed to complete these six configurations.
The document rebuild uses saved results and spends no Colab units.

Read [the full easy thesis](../easy-thesis/FULL-THESIS.md), including benchmark, difficulty, token and uncertainty tables.
The formal thesis retains its historical results.
[Checked result archive and calculations](../results/lora-controls/README.md).

## Full 464 update — 14 October 2026

**2B LoRA-1 alone: 34.4%;4B LoRA-1 alone: 56.8%. Both now cover 464/464.**
The exact missing40 runs passed 1/40 (2B) and 12/40 (4B), with one attempt each.
No existing 424 LoRA-alone IDs were repeated.
The scores above average attempts within problems, then weight problems equally.

For 2B on the same 464 first attempts:
**LoRA + limit1024: 41.2% (191/464); LoRA alone: 34.9% (162/464); OFF: 32.5% (151/464).**
The combination's gain over LoRA alone is 6.2 points, interval +2.4 to +10.1.
Its gain over OFF is 8.6 points, interval +4.5 to +12.9.
LoRA alone's smaller lead over OFF remains inconclusive.
Limit alone is 38.6%; the combination's gain over it remains inconclusive.

Missing40 work is complete. Do not rerun Notebook 22 or the existing 424 answers.
Other incomplete methods remain outside scope.
[Updated results and both weighting rules](../results/lora-missing40/README.md).


## Current combined view — 464 unique problems

Use [combined/README.md](combined/README.md) for the updated easy-thesis numbers.
Full-coverage headlines: **0.8B OFF 14.7% · 2B limit 1,024 38.6% · 4B limit 2,048 71.9%**.
Every problem has equal weight. Missing methods show coverage, and comparisons use shared IDs.
The [easy thesis](../easy-thesis/PAPER.md) now leads with these combined scores.
The tables below are **historical run-specific results**, not the combined ranking.
Original raw scores remain unchanged.

---

> **Start here when you write the paper.**  
> Every main number lives in one of the files below. Rebuild join tables with:
> `python scripts/make_size_summary.py …` and `python scripts/make_all_results.py`.

---

## 1. One picture

```text
                    same 234 code problems
                            │
           ┌────────────────┼────────────────┐
           ▼                ▼                ▼
         0.8B              2B               4B
      (lean, 1 try)    (main, 2 tries)   (full, 2 tries)
           │                │                │
      OFF 20.5%      limit1024 49.8%   limit2048 78.2%
      LoRA 17.9%     LoRA 45.5%        LoRA 69.9%
```

**Paper sentence:** A free control beats LoRA-1 on every size; the best free way grows with size (OFF → 1k → 2k).

---

## 2. Where each number lives

| Need | File |
|---|---|
| **Side-by-side all sizes** | [SIZE-COMPARISON.md](SIZE-COMPARISON.md) |
| **Join accuracy table** | [ALL-RESULTS.md](ALL-RESULTS.md) |
| **0.8B summary + story** | [0.8b/SUMMARY.md](0.8b/SUMMARY.md) · [0.8b/RUN.md](0.8b/RUN.md) |
| **2B short results** | [2026-09-24-thesis-run.md](2026-09-24-thesis-run.md) |
| **2B full (charts, every problem)** | [full-results/FULL-RESULTS.md](full-results/FULL-RESULTS.md) |
| **4B summary + story** | [4b/SUMMARY.md](4b/SUMMARY.md) · [4b/RUN.md](4b/RUN.md) |
| **2B limit512 fill-in** | ✅ **45.1%** (2 tries) | [2b-limit512/SUMMARY.md](2b-limit512/SUMMARY.md) · [2b-limit512/RUN.md](2b-limit512/RUN.md) · notebook [16](../notebooks/16_qwen35_2b_limit512.ipynb) |
| **2B limit2048 fill-in** | ✅ **46.6%** (1 try) | [2b-limit2048/SUMMARY.md](2b-limit2048/SUMMARY.md) · [2b-limit2048/RUN.md](2b-limit2048/RUN.md) · notebook [17](../notebooks/17_qwen35_2b_limit2048.ipynb) |
| **Hours ledger** | [shared/hours_budget.json](shared/hours_budget.json) |
| **Extra 40 problems (scored)** | [extra/SUMMARY.md](extra/SUMMARY.md) · [extra/LISTS.md](extra/LISTS.md) · notebook [18](../notebooks/18_extra_problems.ipynb) |
| **190 more problems (scored)** | [more/SUMMARY.md](more/SUMMARY.md) · [more/RUN.md](more/RUN.md) · [more/LISTS.md](more/LISTS.md) · notebook [19](../notebooks/19_more_problems.ipynb) |
| **All piles, charts, and stats** | [../easy-thesis/10-all-counts.md](../easy-thesis/10-all-counts.md) · 464 tests · train 100 and 280 |
| **Thesis chapters with these numbers** | [../thesis/THESIS.md](../thesis/THESIS.md) §5.13 · §6.7 · §7.5.4 |
| **Teacher talk track** | [../TEACHER-A-TO-Z.md](../TEACHER-A-TO-Z.md) |

### Raw graded files (re-check or re-plot)

| Size | Folder |
|---|---|
| 0.8B | `0.8b/raw/test-*-graded.csv` (+ `.jsonl` answers) |
| 2B | `2026-09-24-thesis-run/` and `full-results/` |
| 4B | `4b/raw/test-*-graded.csv` |
| 2B limit512 | `2b-limit512/raw/` |

---

## 3. Headline numbers (checked)

### Accuracy (%)

| Way | 0.8B (1 try) | 2B (2 tries) | 4B (2 tries) |
|---|---|---|---|
| OFF | **20.5** | 40.8 | 69.7 |
| ON | 7.3 | 42.1 | 64.3 |
| limit512 | 17.5 | **45.1** | 75.4 |
| limit1024 | 13.2 | **49.8** | 76.5 |
| limit2048 | — | **46.6*** | **78.2** |
| limit4096 | — | — | 76.7 |
| LoRA-1 | 17.9 | 45.5 | 69.9 |

\* 2B limit2048 = **1 try** (lean). Other 2B main cells = 2 tries.

**2B limit curve:** 45.1% (512) → **49.8%** (1024) → 46.6% (2048) — **peaks at 1024**.

| limit4096 | — | — | 76.7 |
| LoRA-1 | 17.9 | 45.5 | 69.9 |
| LoRA-2 | n/a | 45.1 | n/a |

### Best free way

| Size | Winner | Score | Beats LoRA-1? |
|---|---|---|---|
| 0.8B | OFF | 20.5% | yes (17.9%) |
| 2B | limit 1024 | 49.8% | yes (45.5%) |
| 4B | limit 2048 | 78.2% | yes (69.9%) |

### Later check: 40 contest problems only

These do **not** replace the table above. Source: [extra/SUMMARY.md](extra/SUMMARY.md). Run: 3.7 hours.

| Way | 0.8B (1 try) | 2B | 4B (2 tries) |
|---|---|---|---|
| OFF | **5.0%** (2/40) | **12.5%** (10/80) | **46.2%** (37/80) |
| ON | 0% | 0% | 18.8% (15/80) |
| limit1024 | 0% | 8.8% (7/80) | not run |
| limit2048 | — | 7.5% (3/40, 1 try) | **46.2%** (37/80) |
| LoRA-1 | 0% | not run | not run |

### Later check: 190 contest problems (1 try)

These do **not** replace the 234 table or the 40 table.
Source: [more/SUMMARY.md](more/SUMMARY.md). Story: [more/RUN.md](more/RUN.md). Run: 7.9 hours.

| Way | 0.8B | 2B | 4B |
|---|---|---|---|
| OFF | **9.5%** (18/190) | 24.7% (47/190) | 66.8% (127/190) |
| ON | 1.1% (2/190) | 13.7% (26/190) | 38.9% (74/190) |
| Best limit | 4.2% (8/190) at 512 | **31.1%** (59/190) at 1024 | **69.5%** (132/190) at 2048 |
| LoRA-1 | 7.9% (15/190) | not run | 46.3% (88/190) |

118 easy, 72 medium. On 4B medium, OFF is 44.4% and the 2,048 limit is 38.9%.
The full-list winner is still the limit, because easy is 88.1% vs 80.5%.

### Thinking ON cut-off on the first exam (hits the wall)

| Size | ON accuracy | Cut-off |
|---|---|---|
| 0.8B | 7.3% | 78% |
| 2B | 42.1% | ~41% |
| 4B | 64.3% | 28% |

---

## 4. What each size run included

| | 0.8B | 2B (main) | 4B |
|---|---|---|---|
| Problems | 234 | 234 | 234 |
| Tries | **1** | 2 | 2 |
| OFF / ON | yes | yes | yes |
| Limits | 512, 1024 | 1024 (+ brief, etc.) | 512–4096 |
| LoRA | LoRA-1 | LoRA-1 + LoRA-2 | LoRA-1 |
| Notebook | 15a | 14 | 15b |
| Status | ✅ done | ✅ done | ✅ done |

---

## 5. Status of related docs (for the paper)

| Doc | Updated with 0.8B/2B/4B? |
|---|---|
| `thesis/THESIS.md` (+ PDF) | ✅ §5.13 / §6.7 / §7.5.4 |
| `results/SIZE-COMPARISON.md` | ✅ |
| `results/ALL-RESULTS.md` | ✅ |
| `0.8b/` · `4b/` SUMMARY + RUN | ✅ |
| `TEACHER-A-TO-Z.md` | ✅ |
| `qa/32–37` | ✅ |
| This index | ✅ |
| Easy thesis later checks (40 and 190) | ✅ `easy-thesis/05-results.md` · `09-extra-problems.md` |
| The 190 scores | ✅ `results/more/SUMMARY.md` · DECISIONS #93 |
| Old proposal (`proposal/`) | Historical (written before size runs) — do not rewrite |
| Early `qa/01–29` | About older steps; leave as history |

---

## 6. Suggested paper outline (from these files)

1. **Intro / question** — thesis Ch 1  
2. **Method (2B)** — Ch 3–4  
3. **Main results (2B)** — Ch 5 + FULL-RESULTS figures  
4. **Why (loops)** — Ch 6  
5. **Size robustness** — SIZE-COMPARISON + Ch 5.13  
6. **Advice + limits** — Ch 7 + honest 1-try note on 0.8B  

DECISIONS #72–#79.
